# -*- coding: utf-8 -*-
"""
Created on Tue Mar 22 22:08:51 2022

@author: AREMAC
"""

import matplotlib. pyplot as plt
from matplotlib.image import imread

img = imread('C:/Users/AREMAC/Pictures/geon.png')

plt.imshow(img)
plt.show()